# using-nrf24l01--modules-mod-6

YouTube video: https://youtu.be/Zd3h6SrsGZM
