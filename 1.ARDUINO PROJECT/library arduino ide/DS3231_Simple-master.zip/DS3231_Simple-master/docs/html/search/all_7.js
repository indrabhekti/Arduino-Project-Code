var searchData=
[
  ['read',['read',['../class_d_s3231___simple.html#adc0540d352010c8db84a2003dd94246b',1,'DS3231_Simple']]],
  ['readeeprombyte',['readEEPROMByte',['../class_d_s3231___simple.html#a225f92ba9c87c02b7d409eae930e10f2',1,'DS3231_Simple']]],
  ['readlog',['readLog',['../class_d_s3231___simple.html#a7cbc3bb7243f570732d385d324f2f665',1,'DS3231_Simple::readLog(DateTime &amp;timestamp, datatype &amp;data)'],['../class_d_s3231___simple.html#a3e5aca7688a2ad18afc4d93de6f03e3f',1,'DS3231_Simple::readLog(DateTime &amp;timestamp, uint8_t *data, uint8_t size=1)']]],
  ['readlogfrom',['readLogFrom',['../class_d_s3231___simple.html#a09ebdb79dd6a9d2f5354e7532fcb9367',1,'DS3231_Simple']]]
];
