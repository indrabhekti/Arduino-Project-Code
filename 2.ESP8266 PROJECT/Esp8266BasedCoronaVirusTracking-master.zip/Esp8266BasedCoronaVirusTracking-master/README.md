# Esp8266BasedCoronaVirusTracking


# Please pay attention to the warnings about corona virus. Let's Stay at home!


 1- Change your wifi information from **WifiConnect.h** file

  `char ssid[32] = "yourssid";`
  `char password[64] = "yourpass";`

 2- Define your country code from **corona.ino** file
 
   `#define country_code "yourcountrycode"`
   
   GET (https://coronavirus-19-api.herokuapp.com/countries) -> all countries info
   
 
 ![alt text][logo]

[logo]: https://github.com/volkanunal/Esp8266BasedCoronaVirusTracking/blob/master/image.jpeg "Logo Title Text 2"
   
   
  
  


